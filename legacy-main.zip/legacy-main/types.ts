
export interface Book {
  title: string;
  coverUrl: string;
  downloadUrl: string;
}
