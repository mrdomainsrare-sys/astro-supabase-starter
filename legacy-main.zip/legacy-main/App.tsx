
import React from 'react';
import { BOOKS_DATA } from './constants';
import BookCard from './components/BookCard';

const App: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <div className="bg-gradient-to-b from-[#071026] to-[#0a1622] text-[#e6eef6] min-h-screen p-5 md:p-10">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8 text-center md:text-left">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight">Rina Kent</h1>
            <p className="mt-2 text-lg text-[#9aa4b2] max-w-2xl mx-auto md:mx-0">
              Rina Kent is a bestselling author known for dark, gripping, psychological storytelling.
            </p>
            <p className="mt-1 text-lg text-[#9aa4b2] max-w-2xl mx-auto md:mx-0">
              Her books blend mystery, tension, and emotional depth.
            </p>
          </div>
        </header>

        <main>
          <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" aria-label="Books list">
            {BOOKS_DATA.map((book) => (
              <BookCard key={book.title} book={book} />
            ))}
          </section>
        </main>

        <footer className="mt-12 text-center text-sm text-[#9aa4b2]">
          © {currentYear} Rina Kent • All rights reserved
        </footer>
      </div>
    </div>
  );
};

export default App;
