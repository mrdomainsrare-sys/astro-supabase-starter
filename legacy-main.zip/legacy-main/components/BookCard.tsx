
import React from 'react';
import { Book } from '../types';

interface BookCardProps {
  book: Book;
}

const BookCard: React.FC<BookCardProps> = ({ book }) => {
  return (
    <article className="bg-gradient-to-b from-[rgba(255,255,255,0.02)] to-[rgba(255,255,255,0.01)] rounded-2xl p-3.5 border border-white/5 shadow-2xl shadow-black/60 transition-transform duration-300 hover:scale-105 hover:shadow-cyan-500/10">
      <div className="h-52 sm:h-64 rounded-xl overflow-hidden bg-gradient-to-b from-[#111827] to-[#0b1220] mb-4" role="img" aria-label={`${book.title} cover`}>
        <img src={book.coverUrl} alt={`${book.title} Cover`} className="w-full h-full object-cover" />
      </div>
      <h2 className="font-bold text-lg truncate text-white mb-3 px-1">{book.title}</h2>
      <div className="flex gap-2 items-center px-1 pb-1">
        <a 
          className="w-full text-center bg-[#e13b5a] text-white py-2.5 px-3.5 rounded-lg font-bold cursor-pointer no-underline hover:bg-opacity-90 transition-colors" 
          href={book.downloadUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          Download PDF
        </a>
      </div>
    </article>
  );
};

export default BookCard;
