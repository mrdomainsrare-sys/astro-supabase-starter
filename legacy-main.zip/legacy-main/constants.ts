
import { Book } from './types';

export const BOOKS_DATA: Book[] = [
  {
    title: 'God Of War',
    coverUrl: 'https://i.postimg.cc/tJq4Trxr/c4239e08284cc1e155963cffb9fb8bc3.jpg',
    downloadUrl: 'https://smrturl.co/8f60d0b',
  },
  {
    title: 'God Of Ruin',
    coverUrl: 'https://i.postimg.cc/2yQnpXf9/download-6.png',
    downloadUrl: 'https://smrturl.co/88e535b',
  },
  {
    title: 'God Of Pain',
    coverUrl: 'https://i.postimg.cc/g0VMcrsV/1174d10493c2be5c8ef53b09030ef5f2.jpg',
    downloadUrl: 'https://smrturl.co/2b0b0d1',
  },
  {
    title: 'God Of Wrath',
    coverUrl: 'https://i.postimg.cc/j5JSJ0WL/download-5.png',
    downloadUrl: 'https://smrturl.co/4be89c8',
  },
  {
    title: 'God Of Malice',
    coverUrl: 'https://i.postimg.cc/Pf8633GB/download-4.png',
    downloadUrl: 'https://smrturl.co/2bd1b51',
  },
  {
    title: 'God Of Fury',
    coverUrl: 'https://i.postimg.cc/zvqh8GB2/b70b09cfc6a6d395199b409b7be693e8.jpg',
    downloadUrl: 'https://smrturl.co/f2a25b4',
  },
];
